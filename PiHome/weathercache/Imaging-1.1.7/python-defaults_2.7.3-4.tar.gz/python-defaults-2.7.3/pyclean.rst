=========
 pyclean
=========

---------------------------
removes .pyc and .pyo files
---------------------------

SYNOPSIS
========
  pyclean [-p PACKAGE | DIR_OR_FILE]

OPTIONS
=======
--version	show program's version number and exit

-h, --help	show this help message and exit

-v, --verbose	turn verbose more one

-q, --quiet	be quiet

-p PACKAGE, --package=PACKAGE	specify Debian package name to clean
