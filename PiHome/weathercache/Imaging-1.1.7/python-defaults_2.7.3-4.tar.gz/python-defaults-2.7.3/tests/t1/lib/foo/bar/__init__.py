print("you just imported foo.bar from %s" % __file__)
