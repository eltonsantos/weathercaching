print("I'm foo")
