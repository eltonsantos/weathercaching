print('spam')
